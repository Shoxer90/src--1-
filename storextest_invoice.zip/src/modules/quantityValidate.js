export const quantityValidate = (input) => {
//   only 
    

}