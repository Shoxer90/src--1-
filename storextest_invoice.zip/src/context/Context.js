import React from 'react';

export const LimitContext = React.createContext();
