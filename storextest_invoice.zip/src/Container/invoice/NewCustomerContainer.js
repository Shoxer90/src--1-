import { Button, Dialog, DialogActions, DialogContent, DialogTitle, IconButton, useMediaQuery, useTheme } from '@mui/material'
import CloseIcon from '@mui/icons-material/Close';
import CustomerInputs from './CustomerInputs';
import TinInput from './TinInput';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import ConfirmDialog from '../../Container2/dialogs/ConfirmDialog';

const NewCustomerContainer = ({
  open, 
  close, 
  isFormValid, 
  setIsFormValid,
  setPaymentInfo,
  paymentInfo,
  validTin, setValidTin
}) => {
  const {t} = useTranslation();
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down('md'));
  const [submitClick, setSubmitClick] = useState(false);
  const [openAttention, setOpenAttention] = useState(false);

  const endOperation = async() => {
    setPaymentInfo({
      ...paymentInfo,
      isInvoice: true
    })
    close()
  };

  const cancelOperation = async() => {
    setSubmitClick(true)
    setPaymentInfo({
      ...paymentInfo,
      invoiceInfo: {},
      isInvoice: false
    })
    close()
  };

  console.log(paymentInfo, "paymentInfo in DIALOG")

  const allKeysFilled = (obj) => {
    const isValid = Object.values(obj)
    .every((value) => value !== undefined &&
      value !== null && 
      value !== ""
    )  && 
     paymentInfo?.partnerTin && 
     paymentInfo?.partnerTin?.length === 8
    setIsFormValid(isValid)
  };

  useEffect(() => {
   paymentInfo?.partnerTin && paymentInfo?.invoiceInfo && allKeysFilled(paymentInfo?.invoiceInfo)
  }, [paymentInfo?.invoiceInfo, paymentInfo?.partnerTin]);

  useEffect(() => {
   !paymentInfo?.partnerTin && setPaymentInfo({
      ...paymentInfo,
      //  "isInvoice": fasle,
    "invoiceInfo": {
      "sourceCountryId": "8c961171-8f04-32ac-8dd0-baf0903d22e5",
      "sourceRegionId": undefined,
      "sourceCommunityId": undefined,
      "sourceResidenceId": undefined,
      "sourceStreet": undefined,
      "destinationCountryId": "8c961171-8f04-32ac-8dd0-baf0903d22e5",
      "destinationRegionId": undefined,
      "destinationCommunityId": undefined,
      "destinationResidenceId": undefined,
      "destinationStreet": undefined
    }
    })
  }, [])
   
  return (
    <Dialog open ={open} fullScreen={fullScreen} maxWidth="800px">
        
      <DialogTitle>{t("settings.createInvoice")}</DialogTitle>
      <IconButton
        aria-label="close"
        onClick={()=>setOpenAttention(true)}
        sx={(theme) => ({
          position: 'absolute',
          right: 8,
          top: 8,
          color: theme.palette.grey[500],
        })}
      >   
        <CloseIcon />
      </IconButton>
      <DialogContent dividers style={{width:"750px",height:"400px",overflow: "hidden" }} >
        <TinInput
          submitClick={submitClick}
          setPaymentInfo={setPaymentInfo}
          paymentInfo={paymentInfo}
          validTin={validTin}
          setValidTin={setValidTin}
        />
        <CustomerInputs 
          submitClick={submitClick}
          setPaymentInfo={setPaymentInfo}
          paymentInfo={paymentInfo}
        />
      </DialogContent>
      <DialogActions>
        <Button onClick={()=>setOpenAttention(true)}>Cancel</Button>
        <Button onClick={endOperation} disabled={!isFormValid || !validTin}>{t("buttons.continue")}</Button>
      </DialogActions>
        <ConfirmDialog
          open={openAttention}
          close={()=>setOpenAttention(false)}
          func={cancelOperation}
          content={t("settings.cleanInvoiceData")}
      />
    </Dialog>
  )
}

export default NewCustomerContainer